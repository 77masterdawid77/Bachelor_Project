import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class HackableServerFrame extends MainFrame {
    private JTextField cUsersUserTextField;
    private JTextArea CTFPlatformVersion0TextArea;
    private JTextArea allEnabledCommandsAreTextArea;
    private JPanel HackMainFrame;
    private JButton backToHomePage;


    public HackableServerFrame(){
        setContentPane(HackMainFrame);
        setTitle("CTF Platform page 2");
        //setSize(1000,600);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setUndecorated(true); //true fullscreen
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        cUsersUserTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && userDirectory() == 1) {
                    CTFPlatformVersion0TextArea.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {
                        case "cat Challenge 1":
                        case "cat Challenge 3":
                        case "cat Challenge 2":
                        case "cd":
                        case "cd help":
                            CTFPlatformVersion0TextArea.append("\n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "ls":
                            CTFPlatformVersion0TextArea.append("HelpFile.txt \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "help":
                            CTFPlatformVersion0TextArea.append("Try using the commands on the right to see what files can be accessed \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cat":
                            CTFPlatformVersion0TextArea.append("Which file do you want to open? - cat filename \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "cat HelpFile.txt":
                            CTFPlatformVersion0TextArea.append(" All the available commands are shown on the right hand side, to go back to the main directory type 'cd ..' with a space between the 2 commands \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "cd ..":
                            userDirectory(0);
                            break;
                        case "clear":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "nmap":
                            CTFPlatformVersion0TextArea.append("Write the Ip address that you want to scan - nmap [Ip Address]");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "nmap 192.164.10.10":
                            CTFPlatformVersion0TextArea.setText("");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("Scanning 192.164.10.10... \n");
                            CTFPlatformVersion0TextArea.append("looking for open ports.. \n");
                            CTFPlatformVersion0TextArea.append("looking for hidden ports.. \n");
                            CTFPlatformVersion0TextArea.append("Found 3 ports! \n port 80 \n port 443 \n port 2673 \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            break;
                        case "collect flag CTF{ForgottenPort}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(1);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{UserFacingCode}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(2);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{badPassword}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(3);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{rootAccess}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(4);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{ModifyingAccessOfSystem}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(5);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "flags collected":
                            CTFPlatformVersion0TextArea.append("Flag Collected = " + flagsFound + "\n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        default:
                            CTFPlatformVersion0TextArea.append("Could not run command \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");

                    }
                    cUsersUserTextField.setText("");
                    }


                if (e.getKeyCode() == KeyEvent.VK_ENTER && userDirectory() == 0){
                    CTFPlatformVersion0TextArea.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {
                        case "ls":
                            CTFPlatformVersion0TextArea.append("Challenge 1, Challenge 2, Challenge 3 \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cat":
                            CTFPlatformVersion0TextArea.append("Which file do you want to open? - cat filename \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "help":
                            CTFPlatformVersion0TextArea.append("Try using the commands on the right to see what files can be accessed \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cd":
                            CTFPlatformVersion0TextArea.append("help \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cd ..":
                            CTFPlatformVersion0TextArea.append("You are in home directory \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cd help":
                            CTFPlatformVersion0TextArea.append("C:/Users/User/help>");
                            userDirectory(1); //move user to help directory
                            break;
                        case "cat Challenge 1":
                            CTFPlatformVersion0TextArea.append("Question 1 - Scan the network 192.164.10.10 and find the robot.txt file \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cat Challenge 2":
                            CTFPlatformVersion0TextArea.append("Question 2 - Scan the network 192.164.10.16 and find the flag inside the website \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "cat Challenge 3":
                            CTFPlatformVersion0TextArea.append("Question 3 - Scan the network 192.164.10.24 and access the root host \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "clear":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "nmap":
                            CTFPlatformVersion0TextArea.append("Write the Ip address that you want to scan - nmap [Ip Address]");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "nmap 192.164.10.10":
                            CTFPlatformVersion0TextArea.setText("");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("Scanning 192.164.10.10... \n");
                            CTFPlatformVersion0TextArea.append("looking for open ports.. \n");
                            CTFPlatformVersion0TextArea.append("looking for hidden ports.. \n");
                            CTFPlatformVersion0TextArea.append("Found 3 ports! \n port 80 \n port 443 \n port 2673 \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            userDirectory(2);
                            break;
                        case "nmap 192.164.10.16":
                            CTFPlatformVersion0TextArea.setText("");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("Scanning 192.164.10.16... \n");
                            CTFPlatformVersion0TextArea.append("looking for open ports.. \n");
                            CTFPlatformVersion0TextArea.append("looking for hidden ports.. \n");
                            CTFPlatformVersion0TextArea.append("Found 1 port! \n port 80 \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User");
                            userDirectory(3);
                            break;
                        case "nmap 192.164.10.24":
                            CTFPlatformVersion0TextArea.setText("");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("Scanning 192.164.10.24... \n");
                            CTFPlatformVersion0TextArea.append("looking for open ports.. \n");
                            CTFPlatformVersion0TextArea.append("looking for hidden ports.. \n");
                            CTFPlatformVersion0TextArea.append("Found 1 port! \n port 143 \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User");
                            userDirectory(4);
                            break;
                        case "collect flag CTF{ForgottenPort}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(1);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{UserFacingCode}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(2);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{badPassword}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(3);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{rootAccess}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(4);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "collect flag CTF{ModifyingAccessOfSystem}":
                            CTFPlatformVersion0TextArea.append("Flag Collected \n");
                            collectFlag(5);
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "flags collected":
                            CTFPlatformVersion0TextArea.append("Flag Collected = " + flagsFound + "\n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        default:
                            CTFPlatformVersion0TextArea.append("Could not run command \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                    }
                    cUsersUserTextField.setText("");
                    }

                if (e.getKeyCode() == KeyEvent.VK_ENTER && userDirectory() == 2){
                    CTFPlatformVersion0TextArea.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {
                        case "exploit 80":
                        case "exploit 443":
                            CTFPlatformVersion0TextArea.append("Not exploitable \n");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            break;
                        case "exploit 2673":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("Found an exploit and running it now... \n");
                            CTFPlatformVersion0TextArea.append("Got into the system \n");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "ls":
                            CTFPlatformVersion0TextArea.append("file1.txt, file3.txt, robot.txt \n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "cat":
                            CTFPlatformVersion0TextArea.append("Which file do you want to open? - cat filename \n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "cat file1.txt":
                            CTFPlatformVersion0TextArea.append("Username: Admin, Password: password123 \n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "cat file3.txt":
                            CTFPlatformVersion0TextArea.append("remember to buy shopping today \n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "cat robot.txt":
                            CTFPlatformVersion0TextArea.append("Remember to disable unused ports on system - CTF{ForgottenPort} \n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "cd":
                            CTFPlatformVersion0TextArea.append("\n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "cd ..":
                            CTFPlatformVersion0TextArea.append("You are in home directory \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            userDirectory(0);
                            break;
                        case "clear":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "nmap":
                            CTFPlatformVersion0TextArea.append("Write the Ip address that you want to scan - nmap [Ip Address]");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        case "nmap 192.164.10.10":
                            CTFPlatformVersion0TextArea.setText("");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("Scanning 192.164.10.10... \n");
                            CTFPlatformVersion0TextArea.append("looking for open ports.. \n");
                            CTFPlatformVersion0TextArea.append("looking for hidden ports.. \n");
                            CTFPlatformVersion0TextArea.append("Found 3 ports! \n port 80 \n port 443 \n port 2673 \n");
                            CTFPlatformVersion0TextArea.append("root:/User>");
                            break;
                        default:
                            CTFPlatformVersion0TextArea.append("Could not run command \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                    }
                    cUsersUserTextField.setText("");
                }

                if (e.getKeyCode() == KeyEvent.VK_ENTER && userDirectory() == 3){
                    CTFPlatformVersion0TextArea.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {
                        case "exploit 80":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("Not found any exploit, trying to open website now... \n");
                            CTFPlatformVersion0TextArea.append("opening the website\n");
                            cUsersUserTextField.setText("");
                            try {
                                //Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler http://www.google.com");
                                URI uri = new URI("file:///C:/Users/44746/IdeaProjects/FYP19,04,2022/Main/exploitableWebsite.html");
                                uri.normalize();
                                Desktop.getDesktop().browse(uri);
                            } catch (IOException | URISyntaxException ex) {
                                ex.printStackTrace();
                            }
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                            break;
                        case "ls":
                            CTFPlatformVersion0TextArea.append("no files found \n");
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                            break;
                        case "cat":
                            CTFPlatformVersion0TextArea.append("Which file do you want to open? - cat filename \n");
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                            break;
                        case "cd":
                            CTFPlatformVersion0TextArea.append("\n");
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                            break;
                        case "cd ..":
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            userDirectory(0);
                            break;
                        case "clear":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                            break;
                        case "nmap":
                            CTFPlatformVersion0TextArea.append("Write the Ip address that you want to scan - nmap [Ip Address]");
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                            break;
                        default:
                            CTFPlatformVersion0TextArea.append("Could not run command \n");
                            CTFPlatformVersion0TextArea.append("D:/User/SamsServer>");
                    }
                    cUsersUserTextField.setText("");
                }

                if (e.getKeyCode() == KeyEvent.VK_ENTER && userDirectory() == 4){
                    CTFPlatformVersion0TextArea.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {
                        case "exploit 143":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("scanning port 143 \n");
                            CTFPlatformVersion0TextArea.append("exploited 143 and got user permissions \n");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "ls":
                            CTFPlatformVersion0TextArea.append("no files found \n");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "cat":
                            CTFPlatformVersion0TextArea.append("Which file do you want to open? - cat filename \n");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "cd":
                            CTFPlatformVersion0TextArea.append("AccessForAdminUsers, AccessForNormalUsers \n");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "cd AccessForNormalUsers":
                            CTFPlatformVersion0TextArea.append(" \n");
                            CTFPlatformVersion0TextArea.append("user:/User/AccessForNormalUsers>");
                            userDirectory(5);
                            break;
                        case "cd AccessForAdminUsers":
                            CTFPlatformVersion0TextArea.append(" \n");
                            if (AccessForAdminUsers == 0){CTFPlatformVersion0TextArea.append("Access Denied \n");}
                            if (AccessForAdminUsers == 1){CTFPlatformVersion0TextArea.append("CTF{ModifyingAccessOfSystem} \n");}
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "cd ..":
                            CTFPlatformVersion0TextArea.append("You are in home directory \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                            userDirectory(0);
                            break;
                        case "clear":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "nmap":
                            CTFPlatformVersion0TextArea.append("Write the Ip address that you want to scan - nmap [Ip Address]");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        default:
                            CTFPlatformVersion0TextArea.append("Could not run command \n");
                            CTFPlatformVersion0TextArea.append("C:/Users/User>");
                    }
                    cUsersUserTextField.setText("");
                }


                if (e.getKeyCode() == KeyEvent.VK_ENTER && userDirectory() == 5){
                    CTFPlatformVersion0TextArea.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {
                        case "chmod 777":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("which folder or directory do you want to change access permissions for?\n");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("user:/User/AccessForNormalUsers>");
                            break;
                        case "chmod 777 AccessForAdminUsers":
                            CTFPlatformVersion0TextArea.setText("");
                            CTFPlatformVersion0TextArea.append("Changed access to allow everything for AccessForAdminUsers folder \n");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("user:/User/AccessForNormalUsers>");
                            AccessForAdminUsers(1);
                            break;
                        case "cd":
                        case "ls":
                            CTFPlatformVersion0TextArea.append("\n");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            break;
                        case "cd ..":
                            CTFPlatformVersion0TextArea.setText("");
                            cUsersUserTextField.setText("");
                            CTFPlatformVersion0TextArea.append("user:/User>");
                            userDirectory(4);
                            break;
                        default:
                            CTFPlatformVersion0TextArea.append("Could not run command \n");
                            CTFPlatformVersion0TextArea.append("user:/User/AccessForNormalUsers>");
                    }
                    cUsersUserTextField.setText("");
                }
            };


        });
        CTFPlatformVersion0TextArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE){
                    //to do

                }
            }
        });
        backToHomePage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                setVisible(false);
                MainFrame myFrame = new MainFrame();
            }
        });
    }

    private int flagsFound = 0;
    private int flag1 = 1;
    private int flag2 = 1;
    private int flag3 = 1;
    private int flag4 = 1;
    private int flag5 = 1;

    private void collectFlag(int i) {
        if (i == 1 && flag1 == 1){flagsFound = flagsFound + 1; flag1 = flag1 - 1;}
        if (i == 2 && flag2 == 1){flagsFound = flagsFound + 1; flag2 = flag2 - 1;}
        if (i == 3 && flag3 == 1){flagsFound = flagsFound + 1; flag3 = flag3 - 1;}
        if (i == 4 && flag4 == 1){flagsFound = flagsFound + 1; flag4 = flag4 - 1;}
        if (i == 5 && flag5 == 1){flagsFound = flagsFound + 1; flag5 = flag5 - 1;}
    }

    private int AccessForAdminUsers = 0;

    private void AccessForAdminUsers(int i) {
        if (i == 1) { AccessForAdminUsers = 1;}
        if (i == 0) { AccessForAdminUsers = 0;}
    }


    private int saveState = 0;

    private void userDirectory(int i) {
        this.saveState = i;
    }

    public int userDirectory() {
        return saveState;
    }

}
