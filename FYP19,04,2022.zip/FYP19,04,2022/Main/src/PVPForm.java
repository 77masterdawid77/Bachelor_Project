import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PVPForm extends MainFrame {
    private JProgressBar progressBar1;
    private JPanel PVPForm;
    private JButton BackButton;
    private JRadioButton answer1RadioButton;
    private JRadioButton answer2RadioButton;
    private JRadioButton answer3RadioButton;
    private JRadioButton answer4RadioButton;
    private JButton submitButton;
    private JLabel question;


    public PVPForm(){
        setContentPane(PVPForm);
        setTitle("CTF Platform page 3");
        //setSize(1000,600);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setUndecorated(true); //true fullscreen
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);


        BackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                setVisible(false);
                MainFrame myFrame = new MainFrame();
            }
        });

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                if (question.getText().contains("Question 1")) {
                    if (answer1RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));
                    question.setText("Question 2 - What is the deanery form of Hexadecimal 1F?");
                    answer1RadioButton.setText("16");
                    answer2RadioButton.setText("15");
                    answer3RadioButton.setText("31");
                    answer4RadioButton.setText("30");

                }
                else if (question.getText().contains("Question 2")) {
                    if (answer3RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 3 - What is nmap used for?");
                    answer1RadioButton.setText("hacking");
                    answer2RadioButton.setText("networking");
                    answer3RadioButton.setText("phishing");
                    answer4RadioButton.setText("setting up database");

                }

                else if (question.getText().contains("Question 3")) {
                    if (answer2RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 4 - What is identity theft?");
                    answer1RadioButton.setText("none of the other 3");
                    answer2RadioButton.setText("using a VPN");
                    answer3RadioButton.setText("stealing data from a system");
                    answer4RadioButton.setText("using other peoples personal information as yours");

                }

                else if (question.getText().contains("Question 4")) {
                    if (answer4RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 5 - What is NOT one of the features of a secure password?");
                    answer1RadioButton.setText("password must be at least 6 characters long");
                    answer2RadioButton.setText("password must contain special characters");
                    answer3RadioButton.setText("writing the same password for every account");
                    answer4RadioButton.setText("having upper and lower case characters");

                }

                else if (question.getText().contains("Question 5")) {
                    if (answer3RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 6 - What is OWASP?");
                    answer1RadioButton.setText("Open Web Application Security Project");
                    answer2RadioButton.setText("Organised Web Application Speed Probing");
                    answer3RadioButton.setText("Open Wireless Application Security Prototype");
                    answer4RadioButton.setText("Over Wire Apparatus Sending Protocol");

                }

                else if (question.getText().contains("Question 6")) {
                    if (answer1RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 7 - What is encryption of a password?");
                    answer1RadioButton.setText("hashing a password");
                    answer2RadioButton.setText("making a password unreadable");
                    answer3RadioButton.setText("adding more characters add the end of password");
                    answer4RadioButton.setText("changing characters so the password cannot be seen");

                }

                else if (question.getText().contains("Question 7")) {
                    if (answer4RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 8 - Which password is the most secure?");
                    answer1RadioButton.setText("password");
                    answer2RadioButton.setText("Password");
                    answer3RadioButton.setText("Password1234#");
                    answer4RadioButton.setText("Password1");

                }

                else if (question.getText().contains("Question 8")) {
                    if (answer3RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question 9 - What is OWASP ZAP tool used for?");
                    answer1RadioButton.setText("scanning");
                    answer2RadioButton.setText("hacking");
                    answer3RadioButton.setText("key-logging");
                    answer4RadioButton.setText("spying");

                }

                else if (question.getText().contains("Question 9")) {
                    if (answer1RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Question  10 - Who owns the internet?");
                    answer1RadioButton.setText("IBM");
                    answer2RadioButton.setText("Everyone");
                    answer3RadioButton.setText("Microsoft");
                    answer4RadioButton.setText("The Government");

                }

                else if (question.getText().contains("Question  10")) {
                    if (answer2RadioButton.isSelected()) {
                        correctAnswers = correctAnswers + 1;
                    }
                    progressBar1.setValue(progressBar1.getValue()+1);
                    progressBar1.setString(String.valueOf(progressBar1.getValue()));

                    question.setText("Your have achieved " + correctAnswers + " questions correctly");
                    answer1RadioButton.setEnabled(false);
                    answer2RadioButton.setEnabled(false);
                    answer3RadioButton.setEnabled(false);
                    answer4RadioButton.setEnabled(false);
                    answer1RadioButton.setText("");
                    answer2RadioButton.setText("");
                    answer3RadioButton.setText("");
                    answer4RadioButton.setText("");
                    submitButton.setEnabled(false);

                }


            }
        });

    }

    int correctAnswers = 0;

}
