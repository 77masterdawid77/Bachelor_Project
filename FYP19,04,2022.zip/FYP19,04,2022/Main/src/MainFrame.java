import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Scanner;

public class MainFrame extends JFrame {
    private JButton checkAnswerButton1;
    private JTextField inputBox1;
    private JPanel mainPanel;
    private JTextField inputBox2;
    private JTextField inputBox3;
    private JTextField inputBox4;
    private JButton checkAnswerButton2;
    private JButton checkAnswerButton3;
    private JButton checkAnswerButton4;
    private JButton resetButton1;
    private JMenuBar MenuBar;
    private JMenu File;
    private JMenuItem fileSave;
    private JMenu Help;
    private JMenuItem About;
    private JMenuItem ResetEverything;
    private JTabbedPane tabbedPane1;
    private JScrollBar scrollBar1;
    private JPanel EasyJPannel;
    private JButton moveToHackableServersButton;
    private JButton checkAnswerButton5;
    private JTextField inputBox5;
    private JButton checkAnswerButton6;
    private JTextField inputBox6;
    private JButton downloadFileButton1;
    private JButton downloadFileButton2;
    private JButton moveToPVPButton;
    private JTextArea terminalTextArea1;
    private JTextField highscore;
    private JTextField currentScore;
    private JLabel Question1Med;
    private JButton uploadQuestion1;
    private JButton uploadQuestion2;
    private JTextField question1MediumInputbox;
    private JButton saveHighscoreButton;
    private JLabel highScoreLabel;
    private JButton hintButton1;
    private JButton checkAnswerButton7;
    private JTextField inputBox7;
    private JMenuItem loadFile;
    private JMenu viewButton;
    private JButton checkAnswerButton8;
    private JTextField inputBox8;
    private JButton hintButton2;
    private JButton hintButton3;
    private JButton hintButton4;
    private JButton hintButton5;
    private JButton hintButton6;
    private JButton hintButton7;
    private JButton hintButton8;
    private JTextField cUsersUserTextField;
    private JTextField question2MediumInputbox;
    private JMenuItem greenView;
    private JMenuItem blueView;
    private JMenuItem grayView;
    private JPanel MediumJPannel;
    private JPanel HardJPannel;
    private JButton MediumCheckAnswer1;
    private JButton MediumCheckAnswer2;
    private JButton MediumCheckAnswer3;
    private JButton downloadFileButton3;
    private JTextField question3MediumInputbox;

    public MainFrame(){
        setContentPane(mainPanel);
        setTitle("CTF Platform");
        //setSize(1000,600);
        setMinimumSize(new Dimension(1000, 600));
        Dimension DimMax = Toolkit.getDefaultToolkit().getScreenSize();
        this.setMaximumSize(DimMax);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setUndecorated(true); //true fullscreen
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        terminalTextArea1.setEditable( false );



        checkAnswerButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input = inputBox1.getText();
                if (input.equals("101")) {
                    inputBox1.setEnabled(false);
                    if (checkAnswerButton1.getText() != "Correct") {
                    int tempnum = Integer.parseInt(currentScore.getText());
                    currentScore.setText(String.valueOf(tempnum+2));
                    checkAnswerButton1.setText("Correct");
                    if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                    }}}
                else {checkAnswerButton1.setText("Wrong, Check answer again?");}
            }
        });

        checkAnswerButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input2 = inputBox2.getText().toUpperCase();
                if (input2.equals("ROUTER") || input2.equals("MODEM")) {
                    inputBox2.setEnabled(false);
                    if (checkAnswerButton2.getText() != "Correct") {
                    int tempnum = Integer.parseInt(currentScore.getText());
                    currentScore.setText(String.valueOf(tempnum+4));
                    checkAnswerButton2.setText("Correct");
                    if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                    }}}
                else {checkAnswerButton2.setText("Wrong, Check answer again?");}
            }
        });
        checkAnswerButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input3 = inputBox3.getText().toUpperCase();
                if (input3.equals("A")) {
                    inputBox3.setEnabled(false);
                    if (checkAnswerButton3.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+2));
                        checkAnswerButton3.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {checkAnswerButton3.setText("Wrong, Check answer again?");}
            }
        });
        checkAnswerButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input4 = inputBox4.getText().toUpperCase();
                if (input4.equals("HTTP") || input4.equals("80")) {
                    inputBox4.setEnabled(false);
                    if (checkAnswerButton4.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+3));
                        checkAnswerButton4.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {checkAnswerButton4.setText("Wrong, Check answer again?");}
            }
        });
        resetButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                checkAnswerButton1.setText("Check Answer!");
                checkAnswerButton2.setText("Check Answer!");
                checkAnswerButton3.setText("Check Answer!");
                checkAnswerButton4.setText("Check Answer!");
                checkAnswerButton5.setText("Check Answer!");
                checkAnswerButton6.setText("Check Answer!");
                checkAnswerButton7.setText("Check Answer!");
                checkAnswerButton8.setText("Check Answer!");
                inputBox1.setText("");
                inputBox2.setText("");
                inputBox3.setText("");
                inputBox4.setText("");
                inputBox5.setText("");
                inputBox6.setText("");
                inputBox7.setText("");
                inputBox8.setText("");
                inputBox1.setEnabled(true);
                inputBox2.setEnabled(true);
                inputBox3.setEnabled(true);
                inputBox4.setEnabled(true);
                inputBox5.setEnabled(true);
                inputBox6.setEnabled(true);
                inputBox7.setEnabled(true);
                inputBox8.setEnabled(true);
                MediumCheckAnswer1.setText("Check Answer!");
                MediumCheckAnswer2.setText("Check Answer!");
                MediumCheckAnswer3.setText("Check Answer!");
                uploadQuestion1.setText("Upload File Here");
                question1MediumInputbox.setEnabled(true);
                question2MediumInputbox.setEnabled(true);
                question3MediumInputbox.setEnabled(true);
                uploadQuestion1.setEnabled(true);
                question1MediumInputbox.setText("");
                question2MediumInputbox.setText("");
                question3MediumInputbox.setText("");
                currentScore.setText("0");
            }
        });
        About.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                ImageIcon icon = new ImageIcon("src/images/turtleIcon.png");
                JOptionPane.showInputDialog(null,"Welcome to the CTF Platform, you can start when you are ready. \nYou can also type your name in the box below but it won't be saved.",
                        "This is the about page", 1);
            }
        });

        greenView.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainPanel.setBackground(new Color(225, 255, 225));
                MenuBar.setBackground(new Color(35, 255, 91));
                tabbedPane1.setBackground(new Color(225, 255, 225));
                EasyJPannel.setBackground(new Color(225, 255, 225));
                MediumJPannel.setBackground(new Color(225, 255, 225));
                HardJPannel.setBackground(new Color(225, 255, 225));
                fileSave.setBackground(new Color(225, 255, 225));
                loadFile.setBackground(new Color(225, 255, 225));
                About.setBackground(new Color(225, 255, 225));
                greenView.setBackground(new Color(225, 255, 225));
                blueView.setBackground(new Color(225, 255, 225));
                grayView.setBackground(new Color(225, 255, 225));
            }
        });

        blueView.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainPanel.setBackground(new Color(168, 255, 229));
                MenuBar.setBackground(new Color(50, 46, 247));
                tabbedPane1.setBackground(new Color(168, 255, 229));
                EasyJPannel.setBackground(new Color(168, 255, 229));
                MediumJPannel.setBackground(new Color(168, 255, 229));
                HardJPannel.setBackground(new Color(168, 255, 229));
                fileSave.setBackground(new Color(168, 255, 229));
                loadFile.setBackground(new Color(168, 255, 229));
                About.setBackground(new Color(168, 255, 229));
                greenView.setBackground(new Color(168, 255, 229));
                blueView.setBackground(new Color(168, 255, 229));
                grayView.setBackground(new Color(168, 255, 229));
            }
        });

        grayView.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainPanel.setBackground(new Color(203, 203, 203, 158));
                MenuBar.setBackground(new Color(203, 203, 203, 5));
                tabbedPane1.setBackground(new Color(203, 203, 203, 158));
                EasyJPannel.setBackground(new Color(203, 203, 203, 158));
                MediumJPannel.setBackground(new Color(203, 203, 203, 158));
                HardJPannel.setBackground(new Color(203, 203, 203, 158));
                fileSave.setBackground(new Color(203, 203, 203, 158));
                loadFile.setBackground(new Color(203, 203, 203, 158));
                About.setBackground(new Color(203, 203, 203, 158));
                greenView.setBackground(new Color(203, 203, 203, 158));
                blueView.setBackground(new Color(203, 203, 203, 158));
                grayView.setBackground(new Color(203, 203, 203, 158));
            }
        });

        moveToHackableServersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                setVisible(false);
                HackableServerFrame page2 = new HackableServerFrame();



              //  setContentPane(EasyJPannel);
            }
        });
        checkAnswerButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input5 = inputBox5.getText().toUpperCase();
                if (input5.equals("PASSWORD") ){
                    inputBox5.setEnabled(false);
                    if (checkAnswerButton5.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+2));
                        checkAnswerButton5.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {checkAnswerButton5.setText("Wrong, Check answer again?");}
            }
        });
        checkAnswerButton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input6 = inputBox6.getText().toUpperCase();
                if (input6.contains("NETWORK") && input6.contains("MAP")) {
                    inputBox6.setEnabled(false);
                    if (checkAnswerButton6.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+2));
                        checkAnswerButton6.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {checkAnswerButton6.setText("Wrong, Check answer again?");}
            }
        });
        moveToPVPButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                setVisible(false);
                PVPForm page3 = new PVPForm();
            }
        });

        highscore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
            }
        });
        highscore.addComponentListener(new ComponentAdapter() {
        });
        currentScore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int number1 = Integer.parseInt(highscore.getText());
                int number2 = Integer.parseInt(currentScore.getText());
                if (number2 > number1) {highscore.setText(currentScore.getText());}
            }
        });
        tabbedPane1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }
        });


        downloadFileButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    //Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler http://www.google.com");
                    URI uri = new URI("file:///C:/Users/44746/IdeaProjects/FYP19,04,2022/Main/src/downloadQuestion1.txt");
                    uri.normalize();
                    Desktop.getDesktop().browse(uri);
                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }

                JFrame parentFrame = new JFrame();

                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Specify where to save the file");

                int userSelection = fileChooser.showSaveDialog(parentFrame);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                }

            }
        });
        uploadQuestion1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JFileChooser chooser = new JFileChooser();
                if (JFileChooser.APPROVE_OPTION == chooser.showOpenDialog(null)) {
                    if (chooser.getSelectedFile().getAbsolutePath().contains("script")){
                        if (uploadQuestion1.getText() != "Correct") {
                            uploadQuestion1.setText("Correct");
                            int tempnum = Integer.parseInt(currentScore.getText());
                            currentScore.setText(String.valueOf(tempnum+5));
                            checkAnswerButton7.setText("Correct");
                            if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                            }
                        }
                    }
                    else{uploadQuestion1.setText("wrong, please try again");}
                }
            }
        });
        saveHighscoreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try{
                    FileWriter highscoreFile = new FileWriter ("Highscore.txt");
                    //highscore.write(highscoreFile);
                    var encoder = new JTextField(" The highscore you achieved: "  + highscore.getText() + vadilityCheck());
                    encoder.write(highscoreFile);

                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Specify a file to save");

                    int userSelection = fileChooser.showSaveDialog(MainFrame.this);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        FileWriter fileToSave = highscoreFile;
                        System.out.println("Save as file: " + fileToSave);
                    }

                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        });



        checkAnswerButton7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input7 = inputBox7.getText().toUpperCase();
                if (input7.contains("CRAWLER") || input7.contains("SPIDER")) {
                    inputBox7.setEnabled(false);
                    if (checkAnswerButton7.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+5));
                        checkAnswerButton7.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {checkAnswerButton7.setText("Wrong, Check answer again?");}
            }
        });
        checkAnswerButton8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String input8 = inputBox8.getText().toUpperCase();
                if (input8.contains("YES")) {
                    inputBox8.setEnabled(false);
                    if (checkAnswerButton8.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+2));
                        checkAnswerButton8.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {checkAnswerButton8.setText("Wrong, Check answer again?");}
            }
        });
        hintButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "Number 1 = Binary 1 \nNumber 2 = Binary 10 \nNumber 3 = Binary 11\nNumber 4 = Binary 100");
            }
        });
        hintButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "What do you have at home that you\n reset when internet is slow");
            }
        });
        hintButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "Number 9 = Hexadecimal 9\n Number 11 = Hexadecimal B\n Number 12 = Hexadecimal C");
            }
        });
        hintButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "Its similar to port 8080 and similar to HTTPS");
            }
        });
        hintButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "The answer is in the question");
            }
        });
        hintButton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "Only the first letter is an abbreviation");
            }
        });
        hintButton7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "A similar word to sneaking or a small animal with 8 legs");
            }
        });
        hintButton8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "Yes or No?");
            }
        });

        fileSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    FileWriter myWriter = new FileWriter("SavedAnswers.txt");
                    myWriter.write(inputBox1.getText() + "\n" + inputBox2.getText() + "\n" + inputBox3.getText() + "\n" + inputBox4.getText() + "\n" + inputBox5.getText() + "\n" + inputBox6.getText() + "\n" + inputBox7.getText() + "\n" + inputBox8.getText() + "\n" + question1MediumInputbox.getText() + "\n" + question2MediumInputbox.getText() + "\n" + uploadQuestion1.getText() + "\n" + question3MediumInputbox.getText() + "\n" + currentScore.getText() + "\n" + highscore.getText());
                    myWriter.close();
                    javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "Successfully Saved.");
                } catch (IOException e) {
                    javax.swing.JOptionPane.showMessageDialog(MainFrame.this, "An error occurred.");
                    e.printStackTrace();
                }

            }
        });

        loadFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    File myObj = new File("SavedAnswers.txt");
                    Scanner myReader = new Scanner(myObj);
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        if (data.contains("101")) {
                            inputBox1.setText("101");
                            inputBox1.setEnabled(false);
                            checkAnswerButton1.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("router")) {
                            inputBox2.setText("router");
                            inputBox2.setEnabled(false);
                            checkAnswerButton2.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("modem")) {
                            inputBox2.setText("modem");
                            inputBox2.setEnabled(false);
                            checkAnswerButton2.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("a")) {
                            inputBox3.setText("a");
                            inputBox3.setEnabled(false);
                            checkAnswerButton3.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("80")) {
                            inputBox4.setText("80");
                            inputBox4.setEnabled(false);
                            checkAnswerButton4.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("http")) {
                            inputBox4.setText("http");
                            inputBox4.setEnabled(false);
                            checkAnswerButton4.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("password")) {
                            inputBox5.setText("password");
                            inputBox5.setEnabled(false);
                            checkAnswerButton5.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("network map")) {
                            inputBox6.setText("network map");
                            inputBox6.setEnabled(false);
                            checkAnswerButton6.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("crawler")) {
                            inputBox7.setText("crawler");
                            inputBox7.setEnabled(false);
                            checkAnswerButton7.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("spider")) {
                            inputBox7.setText("spider");
                            inputBox7.setEnabled(false);
                            checkAnswerButton7.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("yes")) {
                            inputBox8.setText("yes");
                            inputBox8.setEnabled(false);
                            checkAnswerButton8.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("CTF{NotSafeEncryption}")) {
                            question1MediumInputbox.setText("CTF{NotSafeEncryption}");
                            question1MediumInputbox.setEnabled(false);
                            MediumCheckAnswer1.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("CTF{HiddenFileInFolder}")) {
                            question2MediumInputbox.setText("CTF{HiddenFileInFolder}");
                            question2MediumInputbox.setEnabled(false);
                            MediumCheckAnswer2.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("Correct")) {
                            uploadQuestion1.setEnabled(false);
                            MediumCheckAnswer2.setText("Correct");
                        }
                        if (data.equalsIgnoreCase("CTF{ThereIsAlwaysAWay}")) {
                            question3MediumInputbox.setText("CTF{ThereIsAlwaysAWay}");
                            question3MediumInputbox.setEnabled(false);
                            MediumCheckAnswer3.setText("Correct");
                        }
                        if (myReader.hasNextInt()) currentScore.setText(data);
                        if (!myReader.hasNextLine())  highscore.setText(data);

                    }
                    myReader.close();
                } catch (FileNotFoundException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }

            }
        });

        cUsersUserTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER){
                    terminalTextArea1.append(cUsersUserTextField.getText() + "\n");

                    switch(cUsersUserTextField.getText()) {

                        case "cd":
                            terminalTextArea1.append(" - All directories are displayed using this command but were no directories found here \n");
                            break;
                        case "ls":
                            terminalTextArea1.append(" all files are displayed when using this command \n openThisFile.txt \n to open the file type 'cat filename including the .txt part' \n");
                            break;
                        case "clear":
                            terminalTextArea1.setText(" this command cleared all text \n");
                            break;
                        case "cat openThisFile.txt":
                            terminalTextArea1.setText(" this command opens the file in terminals text editor \n Well done you finished the tutorial, now you can progress to terminal page \n");
                            break;
                        case "help":
                            terminalTextArea1.append("This command shows all available commands inside the system \n cd, ls, clear, cat, help \n");
                            break;
                        default:
                            terminalTextArea1.append("Could not run command \n");

                    }
                    terminalTextArea1.append("$Terminal>");
                    cUsersUserTextField.setText("");

            }}});

        terminalTextArea1.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
            }
        });
        MediumCheckAnswer1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                String medInput1 = question1MediumInputbox.getText();
                if (medInput1.contains("CTF{NotSafeEncryption}")) {
                    question1MediumInputbox.setEnabled(false);
                    if (MediumCheckAnswer1.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+5));
                        MediumCheckAnswer1.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {MediumCheckAnswer1.setText("Wrong, Check answer again?");}

            }
        });
        downloadFileButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    //Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler http://www.google.com");
                    URI uri = new URI("file:///C:/Users/44746/IdeaProjects/FYP19,04,2022/Main/src/FlagIsInsideFolder");
                    uri.normalize();
                    Desktop.getDesktop().browse(uri);
                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }

                JFrame parentFrame = new JFrame();

                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Specify where to save the file");

                int userSelection = fileChooser.showSaveDialog(parentFrame);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                }

            }
        });
        MediumCheckAnswer2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                String medInput2 = question2MediumInputbox.getText();
                if (medInput2.contains("CTF{HiddenFileInFolder}")) {
                    question2MediumInputbox.setEnabled(false);
                    if (MediumCheckAnswer2.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+5));
                        MediumCheckAnswer2.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {MediumCheckAnswer2.setText("Wrong, Check answer again?");}

            }
        });
        downloadFileButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    //Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler http://www.google.com");
                    URI uri = new URI("file:///C:/Users/44746/IdeaProjects/FYP19,04,2022/Main/src/downloadChallenge3");
                    uri.normalize();
                    Desktop.getDesktop().browse(uri);
                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }

                JFrame parentFrame = new JFrame();

                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Specify where to save the file");

                int userSelection = fileChooser.showSaveDialog(parentFrame);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                }

            }
        });
        MediumCheckAnswer3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                String medInput3 = question3MediumInputbox.getText();
                if (medInput3.contains("CTF{ThereIsAlwaysAWay}")) {
                    question3MediumInputbox.setEnabled(false);
                    if (MediumCheckAnswer3.getText() != "Correct") {
                        int tempnum = Integer.parseInt(currentScore.getText());
                        currentScore.setText(String.valueOf(tempnum+5));
                        MediumCheckAnswer3.setText("Correct");
                        if (Integer.parseInt(currentScore.getText()) > Integer.parseInt(highscore.getText())) {highscore.setText(currentScore.getText());
                        }}}
                else {MediumCheckAnswer3.setText("Wrong, Check answer again?");}

            }
        });
    }

    public static class AES {

        private static SecretKeySpec secretKey;
        private static byte[] key;

        public static void setKey(final String myKey) {
            MessageDigest sha = null;
            try {
                key = myKey.getBytes("UTF-8");
                //sha = MessageDigest.getInstance("SHA-1");
                //key = sha.digest(key);
                key = Arrays.copyOf(key, 16);
                secretKey = new SecretKeySpec(key, "AES");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        public static String encrypt(final String strToEncrypt, final String secret) {
            try {
                setKey(secret);
                Cipher cipher = Cipher.getInstance("AES");
                cipher.init(Cipher.ENCRYPT_MODE, secretKey);
                return Base64.getEncoder()
                        .encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
            } catch (Exception e) {
                System.out.println("Error while encrypting: " + e.toString());
            }
            return null;
        }

        public static String decrypt(final String strToDecrypt, final String secret) {
            try {
                setKey(secret);
                Cipher cipher = Cipher.getInstance("AES");
                cipher.init(Cipher.DECRYPT_MODE, secretKey);
                return new String(cipher.doFinal(Base64.getDecoder()
                        .decode(strToDecrypt)));
            } catch (Exception e) {
                System.out.println("Error while decrypting: " + e.toString());
            }
            return null;
        }
    }

    private String vadilityCheck() {

        final String secretKey = "keyEncryption123";

        String originalString = highscore.getText();
        String encryptedString = AES.encrypt(originalString, secretKey) ;
        String decryptedString = AES.decrypt(encryptedString, secretKey) ;

        //System.out.println(originalString);
        //System.out.println(encryptedString);
        //System.out.println(decryptedString);

        return " - Code to verify score: " + encryptedString;
    }


    public static void main(String[] args) {
        MainFrame myFrame = new MainFrame();
    }
}
