import javax.swing.*;

public class PVPForm extends MainFrame {
    private JProgressBar progressBar1;
    private JButton buttonDefence;
    private JButton buttonAttack;
    private JPanel PVPForm;
    private JTextArea loginFormLoginUsernameTextArea;
    private JTextArea loginFormLoginUsernameTextArea2;
    private JButton BackButton;


    public PVPForm(){
        setContentPane(PVPForm);
        setTitle("CTF Platform page 3");
        //setSize(1000,600);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        //setUndecorated(true); //true fullscreen
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
    }


}
